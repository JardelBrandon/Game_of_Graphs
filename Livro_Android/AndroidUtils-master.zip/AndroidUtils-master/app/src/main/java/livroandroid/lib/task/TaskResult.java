package livroandroid.lib.task;

/**
 * Created by rlech on 21-May-17.
 */

public class TaskResult<T> {
    public T response;
    public Exception exception;
}
