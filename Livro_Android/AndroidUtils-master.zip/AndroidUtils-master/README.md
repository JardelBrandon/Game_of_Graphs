# AndroidUtils

Versão recomendada:

<pre>
compile 'br.com.livroandroid:android-utils:7.0.0'
</pre>

Compilada com Android Studio 3 preview.

<pre>
compileSdkVersion 27
buildToolsVersion "27.0.3"
</pre>
